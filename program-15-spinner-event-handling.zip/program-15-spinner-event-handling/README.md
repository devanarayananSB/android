# Program 15 – Spinner with Event Handling

**Aim:** Write a program to develop an application that implements Spinner components and performs event handling.

A "Birds Spinner" drop-down (Parrot, Crow, Pigeon, Eagle, Cuckoo). Choosing an item fires `onItemSelected`, which shows a `Toast` with the selection.

## Files
| File | Purpose |
|------|---------|
| `app/src/main/res/layout/activity_main.xml` | UI layout |
| `app/src/main/java/com/example/spinner/MainActivity.java` | Adapter + selection listener |

Package name: `com.example.spinner`

## Changes from the lab record
- `spinner.setSelection(0, false)` was called *before* `setAdapter()`, so it had no effect and a "Selected bird is: Select a bird" toast appeared at launch. It now runs after `setAdapter()`.
- Raw `ArrayAdapter` changed to `ArrayAdapter<String>` (removes the unchecked warning).
- `@color/black` replaced with `@android:color/black`.

## Run
Create an Empty Views Activity project (package `com.example.spinner`) and replace the two files.
