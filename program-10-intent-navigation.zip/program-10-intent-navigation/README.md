# Program 10 – Intent Navigation Between Activities

**Aim:** Write a program to implement Intent to navigate between multiple activities.

A Home page with a **View Profile** button that starts a second activity (`Navigate2`) showing a profile icon and the text "Person Profile".

## Files
| File | Purpose |
|------|---------|
| `app/src/main/res/layout/activity_main.xml` | Home screen layout |
| `app/src/main/res/layout/activity_navigate2.xml` | Profile screen layout |
| `app/src/main/res/drawable/baseline_person_pin_24.xml` | Profile icon (vector) |
| `app/src/main/java/com/example/navigate/MainActivity.java` | Starts `Navigate2` with an `Intent` |
| `app/src/main/java/com/example/navigate/Navigate2.java` | Second activity |

Package name: `com.example.navigate`

## Changes from the lab record
- The record named the layout `activity_navigate.xml` but `Navigate2.java` loads `R.layout.activity_navigate2`, which fails to compile. The file is now `activity_navigate2.xml`.
- The profile icon drawable is included (it was referenced but not provided).
- Added a `contentDescription` on the `ImageView`.

## Manifest
Every activity must be declared. If you create `Navigate2` with Android Studio's *New > Activity* wizard this is done for you; if you copy the file in by hand, add inside `<application>` in `AndroidManifest.xml`:

```xml
<activity android:name=".Navigate2" android:exported="false" />
```

## Run
Create an Empty Views Activity project (package `com.example.navigate`) and copy the files in.
