# Program 8 – Toggle Image using FrameLayout

**Aim:** Write a program to develop an application that toggles an image using FrameLayout.

A `ToggleButton` centred in a `FrameLayout`. Each tap swaps its background between a "volume up" and a "volume mute" icon and shows a `Toast`.

## Files
| File | Purpose |
|------|---------|
| `app/src/main/res/layout/activity_main.xml` | FrameLayout + ToggleButton |
| `app/src/main/res/drawable/baseline_volume_up_24.xml` | Volume-up vector icon |
| `app/src/main/res/drawable/baseline_volume_mute_24.xml` | Muted-speaker vector icon |
| `app/src/main/java/com/example/toggle/MainActivity.java` | Toggle logic |

Package name: `com.example.toggle`

## Changes from the lab record
- The record referenced the two drawables without including them. Both are provided as vector icons.
- Replaced deprecated `setBackgroundDrawable(getResources().getDrawable(...))` with `setBackgroundResource(...)`.
- Added `android:checked="true"` so the starting icon (volume up) matches the toggle state; before, the first tap would have shown "Volume Up" while already showing it.
- Removed the unneeded `android:orientation` on `FrameLayout`.

## Run
Create an Empty Views Activity project (package `com.example.toggle`) and copy the files in.
