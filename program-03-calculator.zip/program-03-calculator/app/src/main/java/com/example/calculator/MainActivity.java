package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText number1, number2;
    TextView result_text;
    Button add_btn, sub_btn, mul_btn, div_btn, clear_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        number1 = findViewById(R.id.number1);
        number2 = findViewById(R.id.number2);
        result_text = findViewById(R.id.result_text);
        add_btn = findViewById(R.id.add_btn);
        sub_btn = findViewById(R.id.sub_btn);
        mul_btn = findViewById(R.id.mul_btn);
        div_btn = findViewById(R.id.div_btn);
        clear_btn = findViewById(R.id.clear_btn);

        add_btn.setOnClickListener(v -> {
            double[] n = readNumbers();
            if (n == null) return;
            show("The addition of the two numbers is: " + (n[0] + n[1]));
        });

        sub_btn.setOnClickListener(v -> {
            double[] n = readNumbers();
            if (n == null) return;
            show("The subtraction of the two numbers is: " + (n[0] - n[1]));
        });

        mul_btn.setOnClickListener(v -> {
            double[] n = readNumbers();
            if (n == null) return;
            show("The multiplication of the two numbers is: " + (n[0] * n[1]));
        });

        div_btn.setOnClickListener(v -> {
            double[] n = readNumbers();
            if (n == null) return;
            if (n[1] == 0) {
                show("Cannot divide by zero");
                return;
            }
            show("The division of the two numbers is: " + (n[0] / n[1]));
        });

        clear_btn.setOnClickListener(v -> {
            number1.setText("");
            number2.setText("");
            result_text.setText("");
            Toast.makeText(getApplicationContext(), "Inputs Cleared....", Toast.LENGTH_SHORT).show();
        });
    }

    /** Reads both inputs. Returns null (and shows a message) if either is empty or invalid. */
    private double[] readNumbers() {
        String t1 = number1.getText().toString().trim();
        String t2 = number2.getText().toString().trim();
        if (t1.isEmpty() || t2.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Please enter both numbers", Toast.LENGTH_SHORT).show();
            return null;
        }
        try {
            return new double[]{Double.parseDouble(t1), Double.parseDouble(t2)};
        } catch (NumberFormatException e) {
            Toast.makeText(getApplicationContext(), "Invalid number", Toast.LENGTH_SHORT).show();
            return null;
        }
    }

    private void show(String message) {
        result_text.setText(message);
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
    }
}
