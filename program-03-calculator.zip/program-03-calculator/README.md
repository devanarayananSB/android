# Program 3 – Simple Calculator

**Aim:** Write a program implementing basic arithmetic operations of a simple calculator.

Two `EditText` fields take the numbers; buttons for `+`, `-`, `x`, `/` and `Clear` show the result in a `TextView` and a `Toast`.

## Files
| File | Purpose |
|------|---------|
| `app/src/main/res/layout/activity_main.xml` | UI layout |
| `app/src/main/java/com/example/calculator/MainActivity.java` | Logic |

Package name: `com.example.calculator`

## Changes from the lab record
- Result text size changed from `175sp` to `17sp` (175sp would not fit on screen).
- Uses `double` instead of `Integer.parseInt` + `float`, so decimals work (the inputs were already `numberDecimal`, which crashed on `2.5`).
- Empty/invalid input shows a message instead of crashing.
- Division by zero is handled.
- Fixed the broken string quotes in the subtraction `Toast`.
- `@color/black` replaced with `@android:color/black`.

## Run
Create an Empty Views Activity project named `Calculator` (package `com.example.calculator`), then replace the two files above.
