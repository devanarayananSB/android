# Program 11 – Explicit Intents

**Aim:** Write a program to develop an application that works with explicit intents.

Three screens chained with explicit intents: `MainActivity` ("admin") -> `Explicit2` ("move to page") -> `Explicit3` ("Go back") -> back to `MainActivity`.

## Files
| File | Purpose |
|------|---------|
| `app/src/main/res/layout/activity_main.xml` | Screen 1 layout |
| `app/src/main/res/layout/activity_explicit2.xml` | Screen 2 layout |
| `app/src/main/res/layout/activity_explicit3.xml` | Screen 3 layout |
| `app/src/main/java/com/example/explicit/MainActivity.java` | Screen 1 -> 2 |
| `app/src/main/java/com/example/explicit/Explicit2.java` | Screen 2 -> 3 |
| `app/src/main/java/com/example/explicit/Explicit3.java` | Screen 3 -> 1 |

Package name: `com.example.explicit`

## Changes from the lab record
- The layout files had invalid XML: `<? xml` with a space, curly quotes in the declaration and in `xmlns:app`, and missing closing quotes on `layout_width="wrap_content` and `layout_height="wrap_content”`.
- `Explicit3.java` declared the field as `button` (lowercase); it must be `Button`.
- Layouts renamed from `SecondActivity.xml` / `ThirdActivity.xml` (uppercase is not allowed in Android resource names) to `activity_explicit2.xml` / `activity_explicit3.xml`, and the `setContentView` calls updated to match.

## Manifest
Declare the two extra activities inside `<application>` in `AndroidManifest.xml` (the New > Activity wizard does this automatically):

```xml
<activity android:name=".Explicit2" android:exported="false" />
<activity android:name=".Explicit3" android:exported="false" />
```

## Run
Create an Empty Views Activity project (package `com.example.explicit`) and copy the files in.
