package com.example.explicit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class Explicit2 extends AppCompatActivity {

    Button goto_third_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_explicit2);

        goto_third_btn = findViewById(R.id.goto_third_btn);

        goto_third_btn.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), Explicit3.class);
            startActivity(intent);
        });
    }
}
