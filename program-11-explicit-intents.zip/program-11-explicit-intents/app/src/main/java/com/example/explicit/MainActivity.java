package com.example.explicit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button goto_second_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        goto_second_btn = findViewById(R.id.goto_second_btn);

        goto_second_btn.setOnClickListener(view -> {
            // Explicit intent: names the target class directly
            Intent intent = new Intent(getApplicationContext(), Explicit2.class);
            startActivity(intent);
        });
    }
}
