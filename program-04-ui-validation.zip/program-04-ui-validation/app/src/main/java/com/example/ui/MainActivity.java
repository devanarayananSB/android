package com.example.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText name_et, email_et, age_et;
    Button submit_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name_et = findViewById(R.id.name_et);
        email_et = findViewById(R.id.email_et);
        age_et = findViewById(R.id.age_et);
        submit_btn = findViewById(R.id.submit_btn);

        submit_btn.setOnClickListener(view -> {
            name_et.setError(null);
            email_et.setError(null);
            age_et.setError(null);

            String name_txt = name_et.getText().toString().trim();
            String email_txt = email_et.getText().toString().trim();
            String age_txt = age_et.getText().toString().trim();

            if (name_txt.isEmpty()) {
                name_et.setError("Please enter your name");
                name_et.requestFocus();
            } else if (email_txt.isEmpty()) {
                email_et.setError("Please enter your email id");
                email_et.requestFocus();
            } else if (!Patterns.EMAIL_ADDRESS.matcher(email_txt).matches()) {
                email_et.setError("Please enter a valid email id");
                email_et.requestFocus();
            } else if (age_txt.isEmpty()) {
                age_et.setError("Please enter your age");
                age_et.requestFocus();
            } else if (!isValidAge(age_txt)) {
                age_et.setError("Please enter a valid age (1-120)");
                age_et.requestFocus();
            } else {
                Toast.makeText(getApplicationContext(), "Form Submitted Successfully",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean isValidAge(String text) {
        try {
            int age = Integer.parseInt(text);
            return age >= 1 && age <= 120;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
