# Program 4 – Validations on UI Controls

**Aim:** Write a program that implements validations on various UI controls.

A "User Form" with Full Name, Email ID and Age. On **Submit**, each field is checked in order and `setError()` shows a message on the first invalid field.

## Files
| File | Purpose |
|------|---------|
| `app/src/main/res/layout/activity_main.xml` | UI layout |
| `app/src/main/java/com/example/ui/MainActivity.java` | Validation logic |

Package name: `com.example.ui`

## Changes from the lab record
- Fixed `android:paddingHorizontal=”20dp”` (curly quotes made the XML invalid).
- Removed unused imports (`CheckBox`, `RadioButton`, `RadioGroup`, `TextView`).
- Added email-format check (`Patterns.EMAIL_ADDRESS`) and age range check (1–120), not just "not empty".
- `@color/black` replaced with `@android:color/black`.

## Run
Create an Empty Views Activity project (package `com.example.ui`) and replace the two files.
