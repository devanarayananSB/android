# Program 7 – Login Page Layout (Facebook-style)

**Aim:** Write a program to create a Facebook page using layout properties in an XML file.

A static login screen: banner image, welcome text, phone/email and password fields, **Log In**, **Forgot Password?** and **Create New**.

## Files
| File | Purpose |
|------|---------|
| `app/src/main/res/layout/activity_main.xml` | UI layout |
| `app/src/main/res/drawable/facebook.xml` | Placeholder banner (solid blue) |
| `app/src/main/java/com/example/applications/MainActivity.java` | Just loads the layout |

Package name: `com.example.applications`

## Changes from the lab record
- The inner `<LinearLayout ... />` was self-closed, so it was empty and its padding/margin did nothing while the fields sat outside it. The fields and buttons are now **inside** it.
- Removed the empty `android:digits=""` attribute and set the first field to `textEmailAddress`.
- Added a placeholder `facebook.xml` drawable so the project compiles.

## Notes
- The aim says *RelativeLayout*, but the record's code uses `LinearLayout` (kept here to match the recorded output). If your lab requires RelativeLayout, the root can be swapped using `layout_below` / `layout_centerHorizontal`.
- Your screenshot shows the Facebook logo as the banner. To use it, delete `facebook.xml` and add your own `facebook.png` to `res/drawable`. Don't keep both files, since the duplicate name will fail the build.

## Run
Create an Empty Views Activity project (package `com.example.applications`) and copy the files in.
